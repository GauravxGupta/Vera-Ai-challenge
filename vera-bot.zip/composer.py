```python
import os
import re
from typing import Dict, Any, Optional
import anthropic

class VeraComposer:
    def __init__(self):
        api_key = os.getenv("ANTHROPIC_API_KEY", "mock-key")
        self.client = anthropic.Anthropic(api_key=api_key)

    def _build_prompt(self, category: Dict, merchant: Dict, trigger: Dict, customer: Optional[Dict], mode: str) -> str:
        languages = merchant.get("languages", ["en"])
        use_hinglish = "hi" in languages or "hinglish" in languages

        prompt = f"""You are Vera, magicpin's growth assistant. Compose a concise WhatsApp message for a merchant/customer.

CONTEXT DATA:
Category: {category.get('name')} | Voice/Tone: {category.get('tone')} | Taboos: {category.get('taboos')}
Merchant: {merchant.get('name')} | Current CTR: {merchant.get('ctr')}% (Peer Median: {merchant.get('peer_ctr')}%) | Active Offers: {merchant.get('offers')}
Trigger Kind: {trigger.get('kind')} | Trigger Details: {trigger.get('details')}
Customer (if applicable): {customer.get('name') if customer else 'N/A'}

STRICT RULES:
1. GROUNDING: Use ONLY verifiable facts provided above (exact numbers, exact price points, exact active offer names). Never invent discounts or stats.
2. LANGUAGE: {"Use natural Hinglish (Hindi-English code-mix) as used in Indian business WhatsApp chats." if use_hinglish else "Use professional, concise English."}
3. CTA: Provide exactly ONE clear binary CTA (e.g., Reply YES to activate) or slot selection CTA.
4. LENGTH: Concise (under 60 words). Direct tone.
"""

        if mode == "ACTION_CONFIRM":
            prompt += "\nMODE: ACTION CONFIRMATION. The merchant agreed! State clearly what campaign/post is being created/published now, and ask for final 'CONFIRM'."
        elif mode == "AUTO_REPLY":
            prompt += "\nMODE: AUTO-REPLY DETECTED. Send a gentle 1-sentence follow-up letting them know you'll wait until they are free."
        elif mode == "OPT_OUT":
            prompt += "\nMODE: OPT-OUT. Send a brief, polite exit message confirming no further automated messages will be sent."

        return prompt

    def compose(self, category: Dict, merchant: Dict, trigger: Dict, customer: Optional[Dict] = None, mode: str = "NORMAL") -> str:
        if os.getenv("ANTHROPIC_API_KEY") is None or os.getenv("ANTHROPIC_API_KEY") == "mock-key":
            return self._fallback_composition(category, merchant, trigger, mode)

        prompt = self._build_prompt(category, merchant, trigger, customer, mode)
        
        response = self.client.messages.create(
            model="claude-3-5-sonnet-20241022",
            max_tokens=200,
            temperature=0.0,
            messages=[{"role": "user", "content": prompt}]
        )
        
        raw_output = response.content[0].text
        return self._apply_guardrails(raw_output)

    def _apply_guardrails(self, text: str) -> str:
        cleaned = text.strip().strip('"')
        if cleaned.count("Reply") > 1:
            lines = cleaned.split("\n")
            cleaned = "\n".join([line for line in lines if "Reply" in line][:1] + [line for line in lines if "Reply" not in line])
        return cleaned

    def _fallback_composition(self, category: Dict, merchant: Dict, trigger: Dict, mode: str) -> str:
        if mode == "OPT_OUT":
            return "Samjh gaya! Hum aapko aage koi updates nahi bhejenge. Have a great day!"
        if mode == "AUTO_REPLY":
            return "Lagta hai aap abhi busy hain. Aap jab free ho, tab bataiye how we can help!"
        if mode == "ACTION_CONFIRM":
            return f"Great! Main {merchant.get('name')} ke liye new campaign draft kar raha hu. Confirm karne ke liye reply karein: CONFIRM."

        offer_str = merchant.get("offers", ["Special Discount"])[0] if merchant.get("offers") else "special service"
        return f"Aapka current CTR {merchant.get('ctr', '2.0')}% hai (peer average: {merchant.get('peer_ctr', '3.0')}%). {offer_str} ko feature karke visibility 2x kar sakte hain. Reply YES to launch now!"

composer = VeraComposer()
```