```python
import time
import re
from typing import Dict, Any, Optional

class ConversationStateManager:
    """Manages multi-turn memory, auto-reply classification, and suppression."""
    
    AUTO_REPLY_PATTERNS = [
        r"thanks for contacting",
        r"we are currently unavailable",
        r"auto-reply",
        r"welcome to our business page",
        r"we will get back to you shortly",
        r"thank you for reaching out"
    ]

    OPT_OUT_PATTERNS = [
        r"\bstop\b",
        r"not interested",
        r"band karo",
        r"don't message me",
        r"unsubscribe"
    ]

    POSITIVE_INTENT_PATTERNS = [
        r"kar do",
        r"go ahead",
        r"let's do it",
        r"yes please",
        r"ha kar do",
        r"do it",
        r"sure"
    ]

    def __init__(self):
        self.state_store: Dict[str, Dict[str, Any]] = {}

    def get_key(self, merchant_id: str, trigger_id: str) -> str:
        return f"{merchant_id}:{trigger_id}"

    def is_suppressed(self, merchant_id: str, trigger_id: str) -> bool:
        key = self.get_key(merchant_id, trigger_id)
        state = self.state_store.get(key)
        if not state:
            return False
        
        now = time.time()
        if state.get("suppressed_until", 0) > now:
            return True
        return False

    def process_incoming_turn(self, merchant_id: str, trigger_id: str, merchant_reply: Optional[str]) -> str:
        if not merchant_reply:
            return "NORMAL"

        reply_lower = merchant_reply.lower().strip()
        key = self.get_key(merchant_id, trigger_id)
        state = self.state_store.setdefault(key, {"turns": 0, "auto_replies": 0})

        for pat in self.OPT_OUT_PATTERNS:
            if re.search(pat, reply_lower):
                state["suppressed_until"] = time.time() + (30 * 86400)
                return "OPT_OUT"

        for pat in self.AUTO_REPLY_PATTERNS:
            if re.search(pat, reply_lower):
                state["auto_replies"] += 1
                if state["auto_replies"] >= 2:
                    state["suppressed_until"] = time.time() + 3600
                return "AUTO_REPLY"

        for pat in self.POSITIVE_INTENT_PATTERNS:
            if re.search(pat, reply_lower):
                return "ACTION_CONFIRM"

        state["turns"] += 1
        return "NORMAL"

state_manager = ConversationStateManager()
```