```python
from fastapi import FastAPI, status
from pydantic import BaseModel
from typing import Dict, Any, Optional
from state_manager import state_manager
from composer import composer

app = FastAPI(
    title="Vera Merchant AI Assistant Engine",
    version="1.0.0",
    description="Production-grade implementation for magicpin AI Challenge"
)

class ContextPayload(BaseModel):
    category: Dict[str, Any]
    merchant: Dict[str, Any]
    trigger: Dict[str, Any]
    customer: Optional[Dict[str, Any]] = None
    merchant_reply: Optional[str] = None

@app.get("/healthz", status_code=status.HTTP_200_OK)
def healthz():
    return {"status": "ok", "service": "Vera Bot Engine"}

@app.post("/api/v1/compose")
def compose_message(payload: ContextPayload):
    merchant_id = str(payload.merchant.get("id", "default_m"))
    trigger_id = str(payload.trigger.get("id", "default_t"))

    if state_manager.is_suppressed(merchant_id, trigger_id):
        return {
            "status": "suppressed",
            "message": "",
            "reason": "Merchant or trigger is currently under suppression cooling period."
        }

    turn_mode = state_manager.process_incoming_turn(
        merchant_id=merchant_id,
        trigger_id=trigger_id,
        merchant_reply=payload.merchant_reply
    )

    message_output = composer.compose(
        category=payload.category,
        merchant=payload.merchant,
        trigger=payload.trigger,
        customer=payload.customer,
        mode=turn_mode
    )

    return {
        "status": "success",
        "turn_mode": turn_mode,
        "message": message_output
    }
```